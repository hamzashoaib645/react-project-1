import Main from './Main/Main'
import './index.css'
function App() {
  return (
    <div>
      <Main />
    </div>
  )
}

export default App
