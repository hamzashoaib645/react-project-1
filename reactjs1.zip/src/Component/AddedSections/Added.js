import React from 'react'
import Entry from '../ClassRoster/AddEntery/Entry'
import { Routes, Route } from 'react-router-dom'
function Added() {
  return (
    <div>
      <Entry />
    </div>
  )
}

export default Added
