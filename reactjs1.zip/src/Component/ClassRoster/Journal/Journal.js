import React from 'react'

import './journal.css'

const Journal = (props) => {
  return (
    <>
      <div className='section-1'>
        <h3 className='journal'> Journal</h3>
        <p className='activi'>No More Activities</p>
      </div>
    </>
  )
}

export default Journal
