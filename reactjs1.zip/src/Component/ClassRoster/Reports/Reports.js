import React from 'react'
import './reports.css'

const Report = (props) => {
  return (
    <>
      <div className='back'>
        <div className='section'>
          <h3 className='Edit'>Edit Reports </h3>
          <p className='notifi'>i</p>
        </div>
      </div>
      <p className='para'>There are currently no open reports today.</p>
    </>
  )
}

export default Report
