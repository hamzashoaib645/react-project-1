import React from 'react'

import './Addfeature.css'
function Addfeature() {
  return (
    <div className='feature-container1'>
      <div className='add-main'>
        <div className='add'>
          <svg
            width='25'
            height='19'
            viewBox='0 0 25 19'
            fill='none'
            xmlns='http://www.w3.org/2000/svg'
          >
            <path
              d='M22.8667 0H1.63333C1.2003 0.000486347 0.785133 0.172726 0.478929 0.47893C0.172725 0.785134 0.000486347 1.2003 0 1.63333V17.15C0.000486347 17.583 0.172725 17.9982 0.478929 18.3044C0.785133 18.6106 1.2003 18.7828 1.63333 18.7833H22.8667C23.2997 18.7828 23.7149 18.6106 24.0211 18.3044C24.3273 17.9982 24.4995 17.583 24.5 17.15V1.63333C24.4995 1.2003 24.3273 0.785134 24.0211 0.47893C23.7149 0.172726 23.2997 0.000486347 22.8667 0V0ZM22.8667 17.15H1.63333V1.63333H22.8667L22.8677 17.15H22.8667Z'
              fill='#FDFBFB'
            />
            <path
              d='M11.025 5.71779H20.4167V7.35113H11.025V5.71779ZM8.16667 9.39279H20.4167V11.0261H8.16667V9.39279ZM8.16667 13.0678H20.4167V14.7011H8.16667V13.0678ZM3.72212 3.67613V10.2566L8.78402 6.71326L3.72212 3.67613Z'
              fill='#FDFBFB'
            />
            <path
              d='M22.8667 0H1.63333C1.2003 0.000486347 0.785133 0.172726 0.478929 0.47893C0.172725 0.785134 0.000486347 1.2003 0 1.63333V17.15C0.000486347 17.583 0.172725 17.9982 0.478929 18.3044C0.785133 18.6106 1.2003 18.7828 1.63333 18.7833H22.8667C23.2997 18.7828 23.7149 18.6106 24.0211 18.3044C24.3273 17.9982 24.4995 17.583 24.5 17.15V1.63333C24.4995 1.2003 24.3273 0.785134 24.0211 0.47893C23.7149 0.172726 23.2997 0.000486347 22.8667 0V0ZM22.8667 17.15H1.63333V1.63333H22.8667L22.8677 17.15H22.8667Z'
              fill='#FDFBFB'
            />
            <path
              d='M11.025 5.71779H20.4167V7.35113H11.025V5.71779ZM8.16667 9.39279H20.4167V11.0261H8.16667V9.39279ZM8.16667 13.0678H20.4167V14.7011H8.16667V13.0678ZM3.72212 3.67613V10.2566L8.78402 6.71326L3.72212 3.67613Z'
              fill='#FDFBFB'
            />
            <path
              d='M11.025 5.71745H20.4167V7.35078H11.025V5.71745ZM8.16668 9.39245H20.4167V11.0258H8.16668V9.39245ZM8.16668 13.0674H20.4167V14.7008H8.16668V13.0674ZM3.72212 3.67578V10.2562L8.78403 6.71291L3.72212 3.67578Z'
              fill='#FDFBFB'
            />
          </svg>
        </div>
        <div className='last'>
          <div className='feature-main'>
            <h2>Add-on Features</h2>

            <div className='icons'>
              <p>
                <svg
                  width='7'
                  height='7'
                  viewBox='0 0 7 7'
                  fill='none'
                  xmlns='http://www.w3.org/2000/svg'
                >
                  <circle cx='3.5' cy='3.5' r='3.5' fill='#00AEEF' />
                </svg>
                Staff Management & Ratios
              </p>
              <svg
                width='7'
                height='7'
                viewBox='0 0 7 7'
                fill='none'
                xmlns='http://www.w3.org/2000/svg'
              >
                <circle cx='3.5' cy='3.5' r='3.5' fill='#00AEEF' />
              </svg>
              Smart Billing
            </div>
          </div>
          <div>
            <a href='./AddOn/AddOn.js'>
              <svg
                className='icon-arrow'
                width='28'
                height='28'
                viewBox='0 0 28 28'
                fill='none'
                xmlns='http://www.w3.org/2000/svg'
              >
                <path
                  d='M26.5 14C26.5 7.09644 20.9036 1.5 14 1.5C7.09644 1.5 1.5 7.09644 1.5 14C1.5 20.9036 7.09644 26.5 14 26.5C20.9036 26.5 26.5 20.9036 26.5 14Z'
                  stroke='#00AEEF'
                  stroke-width='2'
                />
                <path
                  d='M11.125 19L16.125 14L11.125 9'
                  stroke='#00AEEF'
                  stroke-width='2'
                  stroke-linecap='round'
                  stroke-linejoin='round'
                />
              </svg>
            </a>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Addfeature
