import React from 'react'
import './Parent.css'
function Parent() {
  return (
    <div className='Parent11'>
      <h4>Contact</h4>
    </div>
  )
}

export default Parent
